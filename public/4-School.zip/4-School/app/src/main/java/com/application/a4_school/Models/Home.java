package com.application.a4_school.Models;

public class Home {
    private String judul;
    private String detail;

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public int getBghome() {
        return bghome;
    }

    public void setBghome(int bghome) {
        this.bghome = bghome;
    }

    private int bghome;
}
