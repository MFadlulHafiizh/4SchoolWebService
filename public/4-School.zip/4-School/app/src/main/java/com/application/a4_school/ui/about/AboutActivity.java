package com.application.a4_school.ui.about;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.application.a4_school.R;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}