package com.application.a4_school.ui.about;

public class AboutAdapter {
}
